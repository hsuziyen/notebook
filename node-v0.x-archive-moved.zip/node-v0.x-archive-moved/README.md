
This repository is an archive of Node.js before the move to [nodejs/node](https://github.com/nodejs/node).

It still contains issues and pull requests that are relevant to Node versions v0.10 and v0.12, and that were opened before the move to [nodejs/node](https://github.com/nodejs/node).
New issues and pull requests, for all branches, should be opened at [nodejs/node](https://github.com/nodejs/node). 
New issues and pull requests opened here will automatically be rejected.

The pre-convergence version of the README is available [here](https://github.com/nodejs/node-v0.x-archive/blob/master/README-pre-convergence.md). 