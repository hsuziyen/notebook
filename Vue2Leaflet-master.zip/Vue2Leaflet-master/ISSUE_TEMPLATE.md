<!--
If you are asking a question rather than filing a bug, try one of these instead:
- StackOverflow (http://stackoverflow.com/questions/tagged/Vue2Leaflet)
-->
<!-- Instructions For Filing a Bug: https://github.com/KoRiGaN/Vue2Leaflet/blob/master/CONTRIBUTING.md#filing-bugs -->
### Description
<!-- Example: Error thrown when calling `addTo` on Vue2Leaflet component -->

#### Live Demo
<!-- Fork this JSFiddler, or provide your own URL -->
http://jsfiddle.net/Boumi/k04zpLx9/

#### Steps to Reproduce


#### Expected Results
<!-- Example: No error is throw -->

#### Actual Results
<!-- Example: Error is thrown -->

### Browsers Affected
<!-- Check all that apply -->
- [ ] Chrome
- [ ] Firefox
- [ ] Edge
- [ ] Safari 9
- [ ] Safari 8
- [ ] IE 11

### Versions
- Leaflet: vX.X.X
- Vue: vX.X.X
- Vue2Leaflet: vX.X.X
