export default {
  props: {
    options: {
      type: Object,
      default: () => ({})
    }
  }
};
