---
title: LIconDefault
---

# ~~LIconDefault~~

> **Deprecated** since version 2.0

> Set a default icon

## Props

| Prop name | Description | Type   | Values | Default |
| --------- | ----------- | ------ | ------ | ------- |
| imagePath |             | string | -      | ''      |
