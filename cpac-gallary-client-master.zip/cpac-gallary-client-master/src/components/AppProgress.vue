<template>
  <div
    class="text-xs-center"
  >
    <v-progress-circular
      size="70"
      width="5"
      color="primary lighten-4"
      indeterminate
      class="my-5"
    />
  </div>
</template>
