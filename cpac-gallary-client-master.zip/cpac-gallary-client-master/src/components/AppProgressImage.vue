<template>
  <div>
    <v-progress-circular
      size="50"
      color="info lighten-5"
      indeterminate
    />
  </div>
</template>
