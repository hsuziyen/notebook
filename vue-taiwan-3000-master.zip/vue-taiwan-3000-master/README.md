# [郵局振興三倍券 | 即時存量查詢](https://3000.netlify.app/)

![](screenshot.png)

開發紀錄：[https://ovvo.cc/vue-taiwan-3000/](https://ovvo.cc/vue-taiwan-3000/)

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
