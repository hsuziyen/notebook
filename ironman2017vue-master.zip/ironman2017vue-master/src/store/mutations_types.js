export const LOADING = 'LOADING';
export const TOKEN = 'TOKEN';
export const LANGUAGE = 'LANGUAGE';
