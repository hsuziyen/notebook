# 2020 Mask Map

### 專案設定
```
yarn install
```

### 本機需要有 PHP 執行環境

### 用 build --watch
```
yarn build --watch
```

### 利用 PHP -S 來啟動服務
```
php -S 0.0.0.0:8080 -t ./dist
```

