<template>
  <div class="home">
    <h1>home page</h1>
  </div>
</template>

<script>
// @ is an alias to /src


export default {
  name: 'home',
  components: {

  }
}
</script>
