node-sqlite
===========

Connect Node.js to SQLite3.

To install the project. Open up terminal and type

npm install

to run it type.

node sql.js.

Tutorial link :  http://codeforgeek.com/2014/07/node-sqlite-tutorial/


